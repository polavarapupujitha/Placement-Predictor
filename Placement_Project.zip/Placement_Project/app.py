import streamlit as st
import pickle
import numpy as np
import time
from streamlit_lottie import st_lottie
import requests

st.set_page_config(page_title="CareerAI Pro", page_icon="🚀", layout="wide")

# Custom CSS
st.markdown("""
    <style>
    .stApp { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white; }
    .glass-card { background: rgba(255, 255, 255, 0.1); border-radius: 15px; padding: 25px; backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.2); }
    </style>
    """, unsafe_allow_html=True)

def load_lottieurl(url):
    r = requests.get(url)
    return r.json() if r.status_code == 200 else None

lottie_anim = load_lottieurl("https://assets5.lottiefiles.com/packages/lf20_fcfjwiyb.json")

st.title("🚀 CareerAI: Placement Predictor Pro")
st_lottie(lottie_anim, height=150)

st.markdown('<div class="glass-card">', unsafe_allow_html=True)
c1, c2 = st.columns(2)

with c1:
    ssc_p = st.number_input("10th Score (%)", 0.0, 100.0, 80.0)
    degree_p = st.number_input("Degree Score (%)", 0.0, 100.0, 75.0)
    internships = st.slider("Number of Internships", 0, 5, 1)
    workex = st.selectbox("Past Work Experience", ["No", "Yes"])

with c2:
    hsc_p = st.number_input("12th Score (%)", 0.0, 100.0, 75.0)
    etest_p = st.number_input("Aptitude Test Score (%)", 0.0, 100.0, 70.0)
    skills_score = st.slider("Technical Skills Rating (Out of 100)", 0, 100, 70)

st.markdown('</div>', unsafe_allow_html=True)

if st.button("PREDICT MY CAREER PATH"):
    with st.spinner('AI is analyzing your profile...'):
        time.sleep(1)
        model = pickle.load(open('placement_model.pkl', 'rb'))
        workex_val = 1 if workex == "Yes" else 0
        
        # Order: ssc_p, hsc_p, degree_p, workex, internships, skills_score, etest_p
        features = np.array([[ssc_p, hsc_p, degree_p, workex_val, internships, skills_score, etest_p]])
        prediction = model.predict(features)
        prob = model.predict_proba(features)[0][1] * 100

        if prediction[0] == 1:
            st.balloons()
            st.success(f"### 🎉 High Placement Chance: {prob:.1f}%")
        else:
            st.error(f"### 🚩 Low Placement Chance: {prob:.1f}%")
            st.info("💡 Tip: Try to increase your Skills Rating or do more Internships!")