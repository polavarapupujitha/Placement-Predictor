import pandas as pd
import pickle
from sklearn.ensemble import RandomForestClassifier

df = pd.read_csv('placement.csv')
X = df.drop('status', axis=1)
y = df['status']

model = RandomForestClassifier(n_estimators=100)
model.fit(X, y)

with open('placement_model.pkl', 'wb') as f:
    pickle.dump(model, f)
print("✅ New AI Model trained with added features!")