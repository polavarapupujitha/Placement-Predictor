import pandas as pd
import numpy as np

np.random.seed(42)
n = 500
data = {
    'ssc_p': np.random.uniform(50, 95, n),
    'hsc_p': np.random.uniform(50, 95, n),
    'degree_p': np.random.uniform(55, 90, n),
    'workex': np.random.choice([0, 1], n, p=[0.7, 0.3]),
    'internships': np.random.randint(0, 4, n), # 0 to 3 internships
    'skills_score': np.random.uniform(50, 100, n), # Technical skills rating
    'etest_p': np.random.uniform(50, 98, n)
}

df = pd.DataFrame(data)

# New Logic: Internships and Skills ki ekkuva weightage ichanu
score = (df['ssc_p']*0.1 + df['hsc_p']*0.1 + df['degree_p']*0.2 + 
         df['workex']*10 + df['internships']*7 + df['skills_score']*0.3 + df['etest_p']*0.1)

df['status'] = np.where(score > 60, 1, 0)
df.to_csv('placement.csv', index=False)
print("✅ Updated placement.csv with Internships & Skills!")